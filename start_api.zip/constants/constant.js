const NotificationType = {
    friendRequest: 'friendRequest',
    matchInvitation: 'matchInvitation',
    clanInvitation: 'clanInvitation',
    clanApplication: 'clanApplication',
    alertWithSound: 'alertWithSound'
}

module.exports ={
    NotificationType,
}