const express = require("express");
const memberRouter = express.Router();

module.exports = memberRouter;
