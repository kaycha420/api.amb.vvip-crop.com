const express = require("express");
const bankallRouter = express.Router();

module.exports = bankallRouter;
