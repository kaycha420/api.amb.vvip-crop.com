const express = require("express");
const setusettingRouter = express.Router();

module.exports = setusettingRouter;
